package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun PatternCanvas2D(
    piece: PatternPieceData?,
    showGrid: Boolean = true,
    showFormulas: Boolean = true,
    showSeamAllowance: Boolean = true,
    unit: MeasurementUnit = MeasurementUnit.INCHES,
    modifier: Modifier = Modifier
) {
    if (piece == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ParchmentBg),
            contentAlignment = Alignment.Center
        ) {
            Text("No pattern piece selected", style = MaterialTheme.typography.bodyLarge, color = SlateMuted)
        }
        return
    }

    var scale by remember { mutableFloatStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(ParchmentBg)
            .pointerInput(piece) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.4f, 4.0f)
                    offset += pan
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            withTransform({
                translate(left = offset.x + canvasWidth * 0.1f, top = offset.y + canvasHeight * 0.1f)
                scale(scale, scale, pivot = Offset.Zero)
            }) {
                // 1. Draw Grid
                if (showGrid) {
                    drawPatternGrid(size, textMeasurer)
                }

                // Map points for quick lookup
                val pointMap = piece.points.associateBy { it.id }

                // 2. Draw Construction Lines
                piece.lines.filter { it.lineType == LineType.CONSTRUCTION || it.lineType == LineType.CENTER_LINE }.forEach { line ->
                    val start = pointMap[line.fromPointId]
                    val end = pointMap[line.toPointId]
                    if (start != null && end != null) {
                        val isCenter = line.lineType == LineType.CENTER_LINE
                        drawLine(
                            color = if (isCenter) GoldPrimary else SlateMuted.copy(alpha = 0.5f),
                            start = Offset(start.x, start.y),
                            end = Offset(end.x, end.y),
                            strokeWidth = if (isCenter) 2.5f else 1.2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                        )
                    }
                }

                // 3. Draw Curves
                piece.curves.forEach { curve ->
                    val start = pointMap[curve.startPointId]
                    val end = pointMap[curve.endPointId]
                    if (start != null && end != null) {
                        val path = Path().apply {
                            moveTo(start.x, start.y)
                            cubicTo(
                                curve.control1X, curve.control1Y,
                                curve.control2X, curve.control2Y,
                                end.x, end.y
                            )
                        }
                        drawPath(
                            path = path,
                            color = PatternLineMain,
                            style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                        )
                    }
                }

                // 4. Draw Main Outline Lines
                piece.lines.filter { it.lineType == LineType.OUTLINE }.forEach { line ->
                    val start = pointMap[line.fromPointId]
                    val end = pointMap[line.toPointId]
                    if (start != null && end != null) {
                        drawLine(
                            color = PatternLineMain,
                            start = Offset(start.x, start.y),
                            end = Offset(end.x, end.y),
                            strokeWidth = 3.5f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // 5. Draw Darts
                piece.darts.forEach { dart ->
                    val path = Path().apply {
                        moveTo(dart.leftX, dart.leftY)
                        lineTo(dart.apexX, dart.apexY)
                        lineTo(dart.rightX, dart.rightY)
                        close()
                    }
                    drawPath(
                        path = path,
                        color = PatternLineDart.copy(alpha = 0.15f)
                    )
                    drawPath(
                        path = path,
                        color = PatternLineDart,
                        style = Stroke(width = 2.0f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f), 0f))
                    )
                }

                // 6. Draw Seam Allowance (0.5" dashed outer line simulation)
                if (showSeamAllowance) {
                    piece.lines.filter { it.lineType == LineType.OUTLINE }.forEach { line ->
                        val start = pointMap[line.fromPointId]
                        val end = pointMap[line.toPointId]
                        if (start != null && end != null) {
                            // Parallel offset line
                            val dx = end.x - start.x
                            val dy = end.y - start.y
                            val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                            val nx = -dy / len * 9f // 9 units ~ 0.5" offset
                            val ny = dx / len * 9f

                            drawLine(
                                color = PatternLineSeam,
                                start = Offset(start.x + nx, start.y + ny),
                                end = Offset(end.x + nx, end.y + ny),
                                strokeWidth = 1.5f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                            )
                        }
                    }
                }

                // 7. Draw Grainline Arrow
                if (piece.grainLineStart != null && piece.grainLineEnd != null) {
                    val gStart = Offset(piece.grainLineStart.first, piece.grainLineStart.second)
                    val gEnd = Offset(piece.grainLineEnd.first, piece.grainLineEnd.second)
                    drawLine(
                        color = GoldDark,
                        start = gStart,
                        end = gEnd,
                        strokeWidth = 2.0f
                    )
                    // Grainline arrows
                    drawCircle(color = GoldDark, radius = 4f, center = gStart)
                    drawCircle(color = GoldDark, radius = 4f, center = gEnd)
                    
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "GRAIN LINE",
                        topLeft = Offset(gStart.x + 8f, (gStart.y + gEnd.y) / 2.0f),
                        style = TextStyle(color = GoldDark, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }

                // 8. Draw Points and Labels
                piece.points.forEach { point ->
                    drawCircle(
                        color = GoldPrimary,
                        radius = 5.0f,
                        center = Offset(point.x, point.y)
                    )
                    drawCircle(
                        color = PatternLineMain,
                        radius = 2.5f,
                        center = Offset(point.x, point.y)
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = point.label,
                        topLeft = Offset(point.x + 8f, point.y - 12f),
                        style = TextStyle(
                            color = SlateDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }

                // 9. Draw Piece On-Canvas Title Header
                piece.labels.forEach { label ->
                    drawText(
                        textMeasurer = textMeasurer,
                        text = label.text,
                        topLeft = Offset(label.x, label.y),
                        style = if (label.isHeader) {
                            TextStyle(
                                color = SlateDark,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Serif
                            )
                        } else {
                            TextStyle(
                                color = SlateMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    )
                }
            }
        }

        // Floating Control Overlay (Zoom In, Zoom Out, Reset Fit)
        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = SlateDark.copy(alpha = 0.9f),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { scale = (scale * 1.25f).coerceAtMost(4.0f) }) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = GoldLight)
                }
                Text(
                    text = "${(scale * 100).toInt()}%",
                    color = GoldLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                IconButton(onClick = { scale = (scale / 1.25f).coerceAtLeast(0.4f) }) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = GoldLight)
                }
                IconButton(onClick = {
                    scale = 1.0f
                    offset = Offset.Zero
                }) {
                    Icon(Icons.Default.FitScreen, contentDescription = "Fit Screen", tint = GoldLight)
                }
            }
        }

        // Top Information Badge
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            color = SlateDark.copy(alpha = 0.85f),
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = piece.pieceName.uppercase(),
                    color = GoldSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Width: %.1f\" x Height: %.1f\"".format(piece.widthInches, piece.heightInches),
                    color = ParchmentBg,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun DrawScope.drawPatternGrid(size: Size, textMeasurer: TextMeasurer) {
    val gridStep = 18f * 2.0f // 2 inches per major grid square
    val width = size.width * 3.0f
    val height = size.height * 3.0f

    var x = 0f
    while (x < width) {
        drawLine(
            color = PatternGrid,
            start = Offset(x, 0f),
            end = Offset(x, height),
            strokeWidth = 1.0f
        )
        x += gridStep
    }

    var y = 0f
    while (y < height) {
        drawLine(
            color = PatternGrid,
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1.0f
        )
        y += gridStep
    }
}
