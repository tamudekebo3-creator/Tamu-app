package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PatternViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatternDraftScreen(
    viewModel: PatternViewModel,
    modifier: Modifier = Modifier
) {
    val activeMeasurement by viewModel.activeMeasurement.collectAsState()
    val selectedPatternType by viewModel.selectedPatternType.collectAsState()
    val selectedPieceIndex by viewModel.selectedPieceIndex.collectAsState()
    val fitStyle by viewModel.selectedFitStyle.collectAsState()
    val unit by viewModel.selectedUnit.collectAsState()
    val showGrid by viewModel.showGrid.collectAsState()
    val showFormulasOverlay by viewModel.showFormulasOverlay.collectAsState()
    val showSeamAllowance by viewModel.showSeamAllowance.collectAsState()
    val pieces by viewModel.currentPieces.collectAsState()
    val activePiece by viewModel.activePiece.collectAsState()

    var showSaveDialog by remember { mutableStateOf(false) }
    var showFabricDialog by remember { mutableStateOf(false) }
    var showInputsDrawer by remember { mutableStateOf(true) }

    Column(modifier = modifier.fillMaxSize().background(ParchmentBg)) {

        // 1. Top Garment Selection Segmented Buttons (Coat / Trouser / Waistcoat)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SlateDark,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GARMENT PATTERN DRAFT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldSecondary,
                        letterSpacing = 1.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = { viewModel.toggleUnit() }, modifier = Modifier.size(36.dp)) {
                            Text(
                                text = if (unit == MeasurementUnit.INCHES) "IN" else "CM",
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { viewModel.toggleGrid() }, modifier = Modifier.size(36.dp)) {
                            Icon(
                                Icons.Default.GridOn,
                                contentDescription = "Grid",
                                tint = if (showGrid) GoldSecondary else SlateMuted
                            )
                        }
                        IconButton(onClick = { showFabricDialog = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Fabric", tint = GoldLight)
                        }
                        IconButton(onClick = { showSaveDialog = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.BookmarkAdd, contentDescription = "Save Profile", tint = GoldLight)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Garment Selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PatternType.values().forEach { type ->
                        val selected = type == selectedPatternType
                        Button(
                            onClick = { viewModel.selectPatternType(type) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) GoldPrimary else SlateMedium,
                                contentColor = if (selected) SlateDark else ParchmentBg
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(
                                text = type.displayName.split(" ")[0], // Coat / Trouser / Waistcoat
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 2. Piece Tabs (e.g., Front Panel, Back Panel, Sleeve)
        if (pieces.isNotEmpty()) {
            ScrollableTabRow(
                selectedTabIndex = selectedPieceIndex.coerceIn(0, pieces.lastIndex),
                containerColor = SlateMedium,
                contentColor = GoldLight,
                edgePadding = 12.dp
            ) {
                pieces.forEachIndexed { index, p ->
                    Tab(
                        selected = index == selectedPieceIndex,
                        onClick = { viewModel.selectPieceIndex(index) },
                        text = {
                            Text(
                                text = p.pieceName,
                                fontSize = 12.sp,
                                fontWeight = if (index == selectedPieceIndex) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == selectedPieceIndex) GoldSecondary else ParchmentBg.copy(alpha = 0.7f)
                            )
                        }
                    )
                }
            }
        }

        // 3. Interactive Pattern Canvas (Main Viewport)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            PatternCanvas2D(
                piece = activePiece,
                showGrid = showGrid,
                showFormulas = showFormulasOverlay,
                showSeamAllowance = showSeamAllowance,
                unit = unit,
                modifier = Modifier.fillMaxSize()
            )

            // Drawer Toggle Floating Bar
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .clickable { showInputsDrawer = !showInputsDrawer },
                shape = RoundedCornerShape(24.dp),
                color = SlateDark,
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (showInputsDrawer) Icons.Default.ExpandMore else Icons.Default.Tune,
                        contentDescription = "Drawer",
                        tint = GoldSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (showInputsDrawer) "Hide Measurements" else "Adjust Measurements & Formulas",
                        color = GoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 4. Expandable Measurement & Formulas Drawer
        AnimatedVisibility(visible = showInputsDrawer) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(ParchmentSurface)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        MeasurementInputPanel(
                            activeMeasurement = activeMeasurement,
                            selectedPatternType = selectedPatternType,
                            fitStyle = fitStyle,
                            unit = unit,
                            onMeasurementChange = { viewModel.updateMeasurement(it) },
                            onFitChange = { viewModel.setFitStyle(it) },
                            onPresetSelect = { viewModel.loadPreset(it) }
                        )
                    }

                    item {
                        FormulaGuideCard(
                            piece = activePiece
                        )
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        SaveClientDialog(
            currentMeasurement = activeMeasurement,
            onDismiss = { showSaveDialog = false },
            onSave = { name, notes ->
                viewModel.saveCurrentClient(name, notes)
            }
        )
    }

    if (showFabricDialog) {
        FabricCalculatorDialog(
            measurement = activeMeasurement,
            onDismiss = { showFabricDialog = false }
        )
    }
}
