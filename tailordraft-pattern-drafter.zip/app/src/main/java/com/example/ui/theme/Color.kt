package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bespoke Tailor Palette
val SlateDark = Color(0xFF0F172A)
val SlateMedium = Color(0xFF1E293B)
val SlateLight = Color(0xFF334155)
val SlateMuted = Color(0xFF64748B)

val GoldPrimary = Color(0xFFD97706)
val GoldSecondary = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFEF3C7)
val GoldDark = Color(0xFF92400E)

val ParchmentBg = Color(0xFFF8FAFC)
val ParchmentSurface = Color(0xFFFFFFFF)
val ParchmentCard = Color(0xFFF1F5F9)

val PatternLineMain = Color(0xFF0F172A)
val PatternLineSeam = Color(0xFF2563EB) // Blueprint blue for seam allowance
val PatternLineDart = Color(0xFFDC2626) // Red for darts and notch marks
val PatternGrid = Color(0xFFE2E8F0)
val PatternPointText = Color(0xFFB45309)
