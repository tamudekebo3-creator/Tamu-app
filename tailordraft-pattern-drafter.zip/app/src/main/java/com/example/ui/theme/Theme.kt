package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = GoldSecondary,
    onPrimary = SlateDark,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = GoldPrimary,
    onSecondary = SlateDark,
    background = SlateDark,
    onBackground = ParchmentBg,
    surface = SlateMedium,
    onSurface = ParchmentBg,
    surfaceVariant = SlateLight,
    onSurfaceVariant = ParchmentCard
)

private val LightColorScheme = lightColorScheme(
    primary = SlateMedium,
    onPrimary = ParchmentSurface,
    primaryContainer = SlateLight,
    onPrimaryContainer = ParchmentBg,
    secondary = GoldPrimary,
    onSecondary = ParchmentSurface,
    secondaryContainer = GoldLight,
    onSecondaryContainer = GoldDark,
    background = ParchmentBg,
    onBackground = SlateDark,
    surface = ParchmentSurface,
    onSurface = SlateDark,
    surfaceVariant = ParchmentCard,
    onSurfaceVariant = SlateLight
)

@Composable
fun TailorDraftTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use tailor brand palette by default for consistency
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
