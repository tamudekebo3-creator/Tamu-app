package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.ClientRepository
import com.example.ui.theme.*

@Composable
fun MeasurementInputPanel(
    activeMeasurement: ClientMeasurement,
    selectedPatternType: PatternType,
    fitStyle: FitStyle,
    unit: MeasurementUnit,
    onMeasurementChange: (ClientMeasurement) -> Unit,
    onFitChange: (FitStyle) -> Unit,
    onPresetSelect: (ClientMeasurement) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ParchmentSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Header & Presets Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Straighten,
                        contentDescription = "Measurements",
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Body Measurements",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateDark
                    )
                }

                Text(
                    text = "Unit: ${unit.symbol.uppercase()}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldDark,
                    modifier = Modifier
                        .background(GoldLight, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Fit Style Selector Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FitStyle.values().forEach { fit ->
                    val selected = fit == fitStyle
                    FilterChip(
                        selected = selected,
                        onClick = { onFitChange(fit) },
                        label = { Text(fit.displayName, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SlateMedium,
                            selectedLabelColor = GoldLight
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Preset Quick Fill Chips
            Text(
                text = "Quick Presets:",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = SlateMuted
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SuggestionChip(
                    onClick = { onPresetSelect(ClientRepository.PRESET_SLIM_S36) },
                    label = { Text("Slim S36\"", fontSize = 10.sp) }
                )
                SuggestionChip(
                    onClick = { onPresetSelect(ClientRepository.PRESET_MEDIUM_M38) },
                    label = { Text("Standard M40\"", fontSize = 10.sp) }
                )
                SuggestionChip(
                    onClick = { onPresetSelect(ClientRepository.PRESET_LARGE_L44) },
                    label = { Text("Exec L44\"", fontSize = 10.sp) }
                )
            }

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = PatternGrid)

            // Dynamic Inputs based on selected pattern type
            when (selectedPatternType) {
                PatternType.COAT -> {
                    Text(
                        text = "COAT MEASUREMENTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldDark,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    MeasurementStepperRow(
                        label = "Back Length",
                        value = activeMeasurement.coatBackLength,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(coatBackLength = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Shoulder Width",
                        value = activeMeasurement.coatShoulder,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(coatShoulder = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Chest Circumference",
                        value = activeMeasurement.coatChest,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(coatChest = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Waist Circumference",
                        value = activeMeasurement.coatWaist,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(coatWaist = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Sleeve Length",
                        value = activeMeasurement.coatSleeveLength,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(coatSleeveLength = it)) }
                    )
                }

                PatternType.TROUSER -> {
                    Text(
                        text = "TROUSER MEASUREMENTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldDark,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    MeasurementStepperRow(
                        label = "Trouser Length (Outseam)",
                        value = activeMeasurement.trouserLength,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(trouserLength = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Trouser Waist",
                        value = activeMeasurement.trouserWaist,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(trouserWaist = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Hip Circumference",
                        value = activeMeasurement.trouserHip,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(trouserHip = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Inseam Length",
                        value = activeMeasurement.trouserInseam,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(trouserInseam = it)) }
                    )
                }

                PatternType.WAISTCOAT -> {
                    Text(
                        text = "WAISTCOAT MEASUREMENTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldDark,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    MeasurementStepperRow(
                        label = "Shoulder Width",
                        value = activeMeasurement.waistcoatShoulder,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(waistcoatShoulder = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Chest Circumference",
                        value = activeMeasurement.waistcoatChest,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(waistcoatChest = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Waist Circumference",
                        value = activeMeasurement.waistcoatWaist,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(waistcoatWaist = it)) }
                    )
                    MeasurementStepperRow(
                        label = "Front Length",
                        value = activeMeasurement.waistcoatLength,
                        unitSymbol = unit.symbol,
                        onValueChange = { onMeasurementChange(activeMeasurement.copy(waistcoatLength = it)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MeasurementStepperRow(
    label: String,
    value: Float,
    unitSymbol: String,
    onValueChange: (Float) -> Unit
) {
    var textValue by remember(value) { mutableStateOf("%.1f".format(value)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = SlateDark
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = {
                    val newVal = (value - 0.5f).coerceAtLeast(1.0f)
                    onValueChange(newVal)
                },
                modifier = Modifier
                    .size(32.dp)
                    .background(ParchmentCard, CircleShape)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = SlateDark, modifier = Modifier.size(16.dp))
            }

            OutlinedTextField(
                value = textValue,
                onValueChange = { str ->
                    textValue = str
                    str.toFloatOrNull()?.let { onValueChange(it) }
                },
                modifier = Modifier
                    .width(72.dp)
                    .height(48.dp),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                suffix = { Text(unitSymbol, fontSize = 10.sp, color = SlateMuted) }
            )

            IconButton(
                onClick = {
                    val newVal = value + 0.5f
                    onValueChange(newVal)
                },
                modifier = Modifier
                    .size(32.dp)
                    .background(ParchmentCard, CircleShape)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Increase", tint = SlateDark, modifier = Modifier.size(16.dp))
            }
        }
    }
}
