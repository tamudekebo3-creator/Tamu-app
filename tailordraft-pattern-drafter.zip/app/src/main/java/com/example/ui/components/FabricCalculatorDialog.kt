package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClientMeasurement
import com.example.ui.theme.*

@Composable
fun FabricCalculatorDialog(
    measurement: ClientMeasurement,
    onDismiss: () -> Unit
) {
    var fabricWidthInches by remember { mutableFloatStateOf(58f) } // 58" / 150cm is standard suit suiting width
    var garmentSelection by remember { mutableStateOf("FULL_3PIECE") } // "COAT", "TROUSER", "WAISTCOAT", "FULL_2PIECE", "FULL_3PIECE"

    val coatLen = measurement.coatBackLength + measurement.coatSleeveLength + 8.0f
    val trouserLen = (measurement.trouserLength * 2.0f) + 12.0f
    val vestLen = measurement.waistcoatLength + 6.0f

    val totalYards = when (garmentSelection) {
        "COAT" -> (coatLen / 36f) * 1.15f
        "TROUSER" -> (trouserLen / 36f) * 1.1f
        "WAISTCOAT" -> (vestLen / 36f) * 1.1f
        "FULL_2PIECE" -> ((coatLen + trouserLen) / 36f) * 1.05f
        else -> ((coatLen + trouserLen + vestLen) / 36f) * 1.0f
    }
    val totalMeters = totalYards * 0.9144f

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ContentCut, contentDescription = "Fabric", tint = GoldPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Fabric Yardage Estimator", fontWeight = FontWeight.Bold, color = SlateDark)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Estimates cloth required based on pattern piece dimensions, seam allowances and roll width.",
                    fontSize = 12.sp,
                    color = SlateMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Select Outfit:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SlateDark)
                Row(modifier = Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = garmentSelection == "COAT",
                        onClick = { garmentSelection = "COAT" },
                        label = { Text("Coat", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = garmentSelection == "TROUSER",
                        onClick = { garmentSelection = "TROUSER" },
                        label = { Text("Trouser", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = garmentSelection == "WAISTCOAT",
                        onClick = { garmentSelection = "WAISTCOAT" },
                        label = { Text("Vest", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = garmentSelection == "FULL_3PIECE",
                        onClick = { garmentSelection = "FULL_3PIECE" },
                        label = { Text("3-Piece Suit", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SlateDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ESTIMATED FABRIC NEEDED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "%.2f Yards".format(totalYards),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = GoldLight
                            )
                            Text(
                                text = "(%.2f Meters)".format(totalMeters),
                                fontSize = 14.sp,
                                color = ParchmentBg
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Assumes standard 58\" / 150cm cloth width with single directional nap.",
                            fontSize = 10.sp,
                            color = SlateMuted
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = SlateMedium)) {
                Text("Close", color = ParchmentBg)
            }
        },
        shape = RoundedCornerShape(20.dp),
        containerColor = ParchmentSurface
    )
}
