package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun FormulaGuideScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ParchmentBg)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, contentDescription = "Guide", tint = GoldPrimary, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Tailor Formula Handbook",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = SlateDark
                )
                Text(
                    text = "Standard proportion formulas used in bespoke pattern drafting.",
                    fontSize = 11.sp,
                    color = SlateMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                FormulaHandbookSection(
                    title = "1. COAT / JACKET DRAFTING FORMULAS",
                    description = "Traditional 2-piece and 3-piece coat drafting based on chest measurement divisions.",
                    formulas = listOf(
                        "Scye Depth Line" to "Chest / 4 + 0.75\" (or + 2.0 cm)",
                        "Front Neck Width" to "Chest / 12 + 0.5\"",
                        "Front Neck Drop" to "Neck Width + 0.5\"",
                        "Front Chest Width" to "Chest / 4 + 1.5\" (includes chest ease)",
                        "Back Chest Width" to "Chest / 4 + 0.75\"",
                        "Front Waist Width" to "Waist / 4 + 1.25\" (includes side seam shaping)",
                        "Shoulder Drop Slope" to "1.5\" to 1.6\" down from neck line",
                        "Sleeve Cap Crown Height" to "Chest / 4 - 1.0\"",
                        "Sleeve Biceps Width" to "Chest / 3 + 1.0\""
                    )
                )
            }

            item {
                FormulaHandbookSection(
                    title = "2. TROUSER / PANTS DRAFTING FORMULAS",
                    description = "Crotch rise and leg proportions derived from hip and inseam ratios.",
                    formulas = listOf(
                        "Crotch Depth / Rise" to "Hip / 4 + 0.75\" (or Length - Inseam)",
                        "Front Crotch Extension" to "Hip / 16 + 0.25\"",
                        "Back Crotch Extension" to "Hip / 8 + 0.5\" (extended seat curve)",
                        "Front Waist Measurement" to "Waist / 4 + 0.5\" (pleat allowance)",
                        "Back Waist Measurement" to "Waist / 4 + 1.25\" (includes back dart)",
                        "Back Rise Elevation" to "+1.5\" above front waist line for seat depth",
                        "Knee Line Position" to "Rise + Inseam / 2 + 2.0\" down",
                        "Pressed Crease Axis" to "(Front Hip + Crotch Ext) / 2"
                    )
                )
            }

            item {
                FormulaHandbookSection(
                    title = "3. WAISTCOAT / VEST DRAFTING FORMULAS",
                    description = "Close-fitting vest drafting formulas featuring deep V-neck and pointed bottom peaks.",
                    formulas = listOf(
                        "Scye Depth Line" to "Chest / 4 + 0.5\"",
                        "V-Neck Apex Drop" to "12.5\" down from neck origin",
                        "Chest Width" to "Chest / 4 + 0.75\"",
                        "Waist Width" to "Waist / 4 + 0.5\"",
                        "Front Bottom Pointed Peak" to "2.5\" extension below waist level",
                        "Back Length" to "Front Length - 2.5\" (straight hem)",
                        "Back Waist Buckle Strap" to "1.5\" below waist level line"
                    )
                )
            }
        }
    }
}

@Composable
private fun FormulaHandbookSection(
    title: String,
    description: String,
    formulas: List<Pair<String, String>>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ParchmentSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = GoldDark
            )
            Text(
                text = description,
                fontSize = 11.sp,
                color = SlateMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            formulas.forEach { (name, formulaText) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateDark,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = formulaText,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = SlateMedium,
                        modifier = Modifier
                            .background(ParchmentCard, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Divider(color = PatternGrid)
            }
        }
    }
}
