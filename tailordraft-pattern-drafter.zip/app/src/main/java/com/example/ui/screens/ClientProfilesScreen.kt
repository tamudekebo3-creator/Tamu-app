package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClientMeasurement
import com.example.ui.theme.*
import com.example.ui.viewmodel.PatternViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientProfilesScreen(
    viewModel: PatternViewModel,
    onLoadProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clients by viewModel.savedClients.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredClients = clients.filter {
        it.clientName.contains(searchQuery, ignoreCase = true) ||
                it.notes.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = modifier.fillMaxSize().background(ParchmentBg).padding(16.dp)) {
        Text(
            text = "Client Measurement Profiles",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = SlateDark
        )
        Text(
            text = "Manage custom tailored measurements for Coat, Trouser, and Waistcoat.",
            fontSize = 12.sp,
            color = SlateMuted
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search client name or order...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldPrimary) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredClients.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "No clients",
                        tint = SlateMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No saved client profiles found",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateMuted
                    )
                    Text(
                        text = "Save custom measurements from the Draft Screen.",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredClients, key = { it.id }) { client ->
                    ClientProfileCard(
                        client = client,
                        onLoad = {
                            viewModel.loadClientProfile(client)
                            onLoadProfile()
                        },
                        onDelete = {
                            viewModel.deleteClient(client.id)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ClientProfileCard(
    client: ClientMeasurement,
    onLoad: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ParchmentSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = client.clientName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateDark
                    )
                    if (client.notes.isNotBlank()) {
                        Text(
                            text = client.notes,
                            fontSize = 11.sp,
                            color = SlateMuted
                        )
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = PatternLineDart)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Measurement Grid Summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ParchmentCard, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("COAT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldDark)
                    Text("Chest: %.1f\"".format(client.coatChest), fontSize = 11.sp, color = SlateDark)
                    Text("Len: %.1f\"".format(client.coatBackLength), fontSize = 11.sp, color = SlateDark)
                }

                Divider(modifier = Modifier.height(30.dp).width(1.dp), color = PatternGrid)

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("TROUSER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldDark)
                    Text("Waist: %.1f\"".format(client.trouserWaist), fontSize = 11.sp, color = SlateDark)
                    Text("Len: %.1f\"".format(client.trouserLength), fontSize = 11.sp, color = SlateDark)
                }

                Divider(modifier = Modifier.height(30.dp).width(1.dp), color = PatternGrid)

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("WAISTCOAT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoldDark)
                    Text("Chest: %.1f\"".format(client.waistcoatChest), fontSize = 11.sp, color = SlateDark)
                    Text("Len: %.1f\"".format(client.waistcoatLength), fontSize = 11.sp, color = SlateDark)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onLoad,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = SlateDark)
            ) {
                Icon(Icons.Default.Drafts, contentDescription = "Load", tint = GoldSecondary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Load into Pattern Workshop", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}
