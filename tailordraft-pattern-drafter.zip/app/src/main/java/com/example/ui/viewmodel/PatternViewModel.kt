package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.drafting.PatternCalculator
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.ClientRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PatternViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ClientRepository

    val savedClients: StateFlow<List<ClientMeasurement>>

    private val _activeMeasurement = MutableStateFlow(ClientRepository.PRESET_MEDIUM_M38)
    val activeMeasurement: StateFlow<ClientMeasurement> = _activeMeasurement.asStateFlow()

    private val _selectedPatternType = MutableStateFlow(PatternType.COAT)
    val selectedPatternType: StateFlow<PatternType> = _selectedPatternType.asStateFlow()

    private val _selectedPieceIndex = MutableStateFlow(0)
    val selectedPieceIndex: StateFlow<Int> = _selectedPieceIndex.asStateFlow()

    private val _selectedFitStyle = MutableStateFlow(FitStyle.REGULAR)
    val selectedFitStyle: StateFlow<FitStyle> = _selectedFitStyle.asStateFlow()

    private val _selectedUnit = MutableStateFlow(MeasurementUnit.INCHES)
    val selectedUnit: StateFlow<MeasurementUnit> = _selectedUnit.asStateFlow()

    private val _showGrid = MutableStateFlow(true)
    val showGrid: StateFlow<Boolean> = _showGrid.asStateFlow()

    private val _showFormulasOverlay = MutableStateFlow(true)
    val showFormulasOverlay: StateFlow<Boolean> = _showFormulasOverlay.asStateFlow()

    private val _showSeamAllowance = MutableStateFlow(true)
    val showSeamAllowance: StateFlow<Boolean> = _showSeamAllowance.asStateFlow()

    // Calculated pattern pieces for active configuration
    val currentPieces: StateFlow<List<PatternPieceData>> = combine(
        _activeMeasurement,
        _selectedPatternType,
        _selectedFitStyle
    ) { measurement, type, fit ->
        PatternCalculator.generatePieces(measurement, type, fit)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activePiece: StateFlow<PatternPieceData?> = combine(
        currentPieces,
        _selectedPieceIndex
    ) { pieces, index ->
        if (pieces.isNotEmpty()) pieces[index.coerceIn(0, pieces.lastIndex)] else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        val dao = AppDatabase.getDatabase(application).clientDao()
        repository = ClientRepository(dao)
        savedClients = repository.allClients.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun selectPatternType(type: PatternType) {
        _selectedPatternType.value = type
        _selectedPieceIndex.value = 0
    }

    fun selectPieceIndex(index: Int) {
        _selectedPieceIndex.value = index
    }

    fun setFitStyle(fit: FitStyle) {
        _selectedFitStyle.value = fit
    }

    fun toggleUnit() {
        val newUnit = if (_selectedUnit.value == MeasurementUnit.INCHES) MeasurementUnit.CENTIMETERS else MeasurementUnit.INCHES
        _selectedUnit.value = newUnit
    }

    fun toggleGrid() {
        _showGrid.value = !_showGrid.value
    }

    fun toggleFormulasOverlay() {
        _showFormulasOverlay.value = !_showFormulasOverlay.value
    }

    fun toggleSeamAllowance() {
        _showSeamAllowance.value = !_showSeamAllowance.value
    }

    fun updateMeasurement(newMeasurement: ClientMeasurement) {
        _activeMeasurement.value = newMeasurement
    }

    fun loadClientProfile(client: ClientMeasurement) {
        _activeMeasurement.value = client
    }

    fun loadPreset(preset: ClientMeasurement) {
        _activeMeasurement.value = preset
    }

    fun saveCurrentClient(clientName: String, notes: String) {
        viewModelScope.launch {
            val toSave = _activeMeasurement.value.copy(
                clientName = clientName,
                notes = notes,
                updatedAt = System.currentTimeMillis()
            )
            val id = repository.saveClient(toSave)
            _activeMeasurement.value = toSave.copy(id = id)
        }
    }

    fun deleteClient(id: Long) {
        viewModelScope.launch {
            repository.deleteClient(id)
        }
    }
}
