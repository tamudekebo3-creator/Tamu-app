package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ClientMeasurement
import com.example.ui.theme.*

@Composable
fun SaveClientDialog(
    currentMeasurement: ClientMeasurement,
    onDismiss: () -> Unit,
    onSave: (name: String, notes: String) -> Unit
) {
    var clientName by remember { mutableStateOf(currentMeasurement.clientName.ifEmpty { "New Client" }) }
    var notes by remember { mutableStateOf(currentMeasurement.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Save Client Profile",
                fontWeight = FontWeight.Bold,
                color = SlateDark
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Save these custom Coat, Trouser & Waistcoat measurements for future drafting.",
                    fontSize = 12.sp,
                    color = SlateMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Client Full Name / Order ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (e.g. Wedding Tuxedo, Wool Blend)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (clientName.isNotBlank()) {
                        onSave(clientName, notes)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text("Save Profile", color = SlateDark, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SlateMuted)
            }
        },
        shape = RoundedCornerShape(20.dp),
        containerColor = ParchmentSurface
    )
}
