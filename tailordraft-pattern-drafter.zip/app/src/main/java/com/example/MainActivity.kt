package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ClientProfilesScreen
import com.example.ui.screens.FormulaGuideScreen
import com.example.ui.screens.PatternDraftScreen
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.ParchmentBg
import com.example.ui.theme.SlateDark
import com.example.ui.theme.TailorDraftTheme
import com.example.ui.viewmodel.PatternViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TailorDraftTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    val viewModel: PatternViewModel = viewModel()
    var selectedScreenIndex by remember { mutableIntStateOf(0) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = SlateDark,
                contentColor = ParchmentBg
            ) {
                NavigationBarItem(
                    selected = selectedScreenIndex == 0,
                    onClick = { selectedScreenIndex = 0 },
                    icon = { Icon(Icons.Default.Straighten, contentDescription = "Draft Workshop") },
                    label = { Text("Pattern Draft", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SlateDark,
                        selectedTextColor = GoldSecondary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = ParchmentBg.copy(alpha = 0.6f),
                        unselectedTextColor = ParchmentBg.copy(alpha = 0.6f)
                    )
                )

                NavigationBarItem(
                    selected = selectedScreenIndex == 1,
                    onClick = { selectedScreenIndex = 1 },
                    icon = { Icon(Icons.Default.People, contentDescription = "Clients") },
                    label = { Text("Saved Profiles", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SlateDark,
                        selectedTextColor = GoldSecondary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = ParchmentBg.copy(alpha = 0.6f),
                        unselectedTextColor = ParchmentBg.copy(alpha = 0.6f)
                    )
                )

                NavigationBarItem(
                    selected = selectedScreenIndex == 2,
                    onClick = { selectedScreenIndex = 2 },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = "Handbook") },
                    label = { Text("Formulas", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SlateDark,
                        selectedTextColor = GoldSecondary,
                        indicatorColor = GoldPrimary,
                        unselectedIconColor = ParchmentBg.copy(alpha = 0.6f),
                        unselectedTextColor = ParchmentBg.copy(alpha = 0.6f)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedScreenIndex) {
                0 -> PatternDraftScreen(viewModel = viewModel)
                1 -> ClientProfilesScreen(
                    viewModel = viewModel,
                    onLoadProfile = { selectedScreenIndex = 0 }
                )
                2 -> FormulaGuideScreen()
            }
        }
    }
}
