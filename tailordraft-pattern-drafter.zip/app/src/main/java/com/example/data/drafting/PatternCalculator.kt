package com.example.data.drafting

import com.example.data.model.*
import kotlin.math.cos
import kotlin.math.sin

object PatternCalculator {

    private const val SCALE = 18.0f // 18 vector DP per inch for crisp canvas scaling

    fun generatePieces(
        m: ClientMeasurement,
        type: PatternType,
        fit: FitStyle = FitStyle.REGULAR
    ): List<PatternPieceData> {
        val ease = fit.easeMultiplier
        return when (type) {
            PatternType.COAT -> listOf(
                calculateCoatFront(m, ease),
                calculateCoatBack(m, ease),
                calculateCoatSleeve(m, ease)
            )
            PatternType.TROUSER -> listOf(
                calculateTrouserFront(m, ease),
                calculateTrouserBack(m, ease)
            )
            PatternType.WAISTCOAT -> listOf(
                calculateWaistcoatFront(m, ease),
                calculateWaistcoatBack(m, ease)
            )
        }
    }

    // ==========================================
    // COAT DRAFTING FORMULAS
    // ==========================================

    private fun calculateCoatFront(m: ClientMeasurement, ease: Float): PatternPieceData {
        val chest = m.coatChest
        val waist = m.coatWaist
        val length = m.coatBackLength
        val shoulder = m.coatShoulder

        val scyeDepth = (chest / 4.0f + 0.75f) * ease
        val waistLine = 17.0f
        val chestWidth = (chest / 4.0f + 1.5f) * ease
        val waistWidth = (waist / 4.0f + 1.25f) * ease
        val neckWidth = chest / 12.0f + 0.5f
        val neckDepth = neckWidth + 0.5f
        val shoulderWidth = (shoulder / 2.0f) - 0.25f
        val shoulderDrop = 1.6f
        val lapelWidth = 3.25f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val drts = mutableListOf<DraftDart>()
        val lbls = mutableListOf<DraftLabel>()

        // Coordinate Origin top-left
        val ox = 60f
        val oy = 40f

        // Points
        val pNeckStart = DraftPoint("N0", "0", ox, oy, "Origin / Back Neck Level")
        val pNeckCurveTop = DraftPoint("N1", "1", ox + neckWidth * SCALE, oy, "Front Neck Width (Chest/12 + 0.5\")")
        val pNeckFront = DraftPoint("N2", "2", ox, oy + neckDepth * SCALE, "Front Neck Drop")
        val pLapelTip = DraftPoint("L1", "Lapel", ox - lapelWidth * SCALE, oy + (neckDepth + 2f) * SCALE, "Lapel Point")
        
        val pShoulderTip = DraftPoint("S1", "3", ox + shoulderWidth * SCALE, oy + shoulderDrop * SCALE, "Shoulder Point")
        val pScyeLine = DraftPoint("B1", "4", ox, oy + scyeDepth * SCALE, "Scye Depth (Chest/4 + 0.75\")")
        val pChestWidth = DraftPoint("B2", "5", ox + chestWidth * SCALE, oy + scyeDepth * SCALE, "Chest Line Width")
        
        val pWaistLine = DraftPoint("W1", "6", ox, oy + waistLine * SCALE, "Waist Line Level")
        val pWaistWidth = DraftPoint("W2", "7", ox + waistWidth * SCALE, oy + waistLine * SCALE, "Waist Front Width")
        
        val pHemLine = DraftPoint("H1", "8", ox, oy + length * SCALE, "Full Coat Length")
        val pHemWidth = DraftPoint("H2", "9", ox + (waistWidth + 0.75f) * SCALE, oy + length * SCALE, "Hem Front Width")

        pts.addAll(listOf(pNeckStart, pNeckCurveTop, pNeckFront, pLapelTip, pShoulderTip, pScyeLine, pChestWidth, pWaistLine, pWaistWidth, pHemLine, pHemWidth))

        // Lines
        lns.add(DraftLine("N1", "S1", LineType.OUTLINE, "Shoulder Seam"))
        lns.add(DraftLine("N2", "L1", LineType.OUTLINE, "Lapel Cut"))
        lns.add(DraftLine("L1", "W1", LineType.OUTLINE, "Front Closure"))
        lns.add(DraftLine("W1", "H1", LineType.OUTLINE, "Center Front Line"))
        lns.add(DraftLine("H1", "H2", LineType.OUTLINE, "Bottom Hem"))
        lns.add(DraftLine("W2", "H2", LineType.OUTLINE, "Lower Side Seam"))

        // Construction Reference Lines
        lns.add(DraftLine("N0", "H1", LineType.CENTER_LINE, "Center Front Grain"))
        lns.add(DraftLine("B1", "B2", LineType.CONSTRUCTION, "Chest Level"))
        lns.add(DraftLine("W1", "W2", LineType.CONSTRUCTION, "Waist Level"))

        // Armhole Scye Curve (S1 to B2)
        crvs.add(DraftCurve(
            startPointId = "S1",
            control1X = ox + (shoulderWidth - 0.5f) * SCALE,
            control1Y = oy + (scyeDepth * 0.5f) * SCALE,
            control2X = ox + (chestWidth - 1.0f) * SCALE,
            control2Y = oy + (scyeDepth - 0.5f) * SCALE,
            endPointId = "B2",
            label = "Armhole Scye Curve"
        ))

        // Side Seam Curve (B2 to W2)
        crvs.add(DraftCurve(
            startPointId = "B2",
            control1X = ox + (chestWidth - 0.2f) * SCALE,
            control1Y = oy + (scyeDepth + (waistLine - scyeDepth) * 0.5f) * SCALE,
            control2X = ox + (waistWidth + 0.3f) * SCALE,
            control2Y = oy + (waistLine - 1f) * SCALE,
            endPointId = "W2",
            label = "Side Waist Shaping"
        ))

        // Neck Curve (N1 to N2)
        crvs.add(DraftCurve(
            startPointId = "N1",
            control1X = ox + (neckWidth * 0.5f) * SCALE,
            control1Y = oy + (neckDepth * 0.8f) * SCALE,
            control2X = ox + 0.5f * SCALE,
            control2Y = oy + neckDepth * SCALE,
            endPointId = "N2",
            label = "Front Neck Curve"
        ))

        // Front Waist Dart
        val dartX = ox + (chestWidth * 0.5f) * SCALE
        val dartApexY = oy + (scyeDepth + 1.5f) * SCALE
        val dartBottomY = oy + (waistLine + 5.0f) * SCALE
        drts.add(DraftDart(dartX, dartApexY, dartX - 0.35f * SCALE, oy + waistLine * SCALE, dartX + 0.35f * SCALE, oy + waistLine * SCALE))

        // Labels
        lbls.add(DraftLabel("COAT FRONT PANEL", ox + 2.0f * SCALE, oy + 5.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pieces (Main Fabric)", ox + 2.0f * SCALE, oy + 6.2f * SCALE))

        val formulas = listOf(
            FormulaStep("A to 1 (Neck Width)", "Chest / 12 + 0.5\"", "%.2f\"".format(neckWidth), "Establishes front collar width"),
            FormulaStep("A to 4 (Scye Depth)", "(Chest / 4 + 0.75\") * Fit", "%.2f\"".format(scyeDepth), "Armhole vertical depth line"),
            FormulaStep("4 to 5 (Chest Width)", "(Chest / 4 + 1.5\") * Fit", "%.2f\"".format(chestWidth), "Includes chest movement ease"),
            FormulaStep("6 to 7 (Waist Width)", "(Waist / 4 + 1.25\") * Fit", "%.2f\"".format(waistWidth), "Waist side curve boundary")
        )

        return PatternPieceData(
            pieceName = "Coat Front Panel",
            category = PatternType.COAT,
            points = pts,
            lines = lns,
            curves = crvs,
            darts = drts,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + 2.0f * SCALE, oy + 8.0f * SCALE),
            grainLineEnd = Pair(ox + 2.0f * SCALE, oy + (length - 3.0f) * SCALE),
            widthInches = chestWidth + lapelWidth + 2f,
            heightInches = length + 2f
        )
    }

    private fun calculateCoatBack(m: ClientMeasurement, ease: Float): PatternPieceData {
        val chest = m.coatChest
        val waist = m.coatWaist
        val length = m.coatBackLength
        val shoulder = m.coatShoulder

        val scyeDepth = (chest / 4.0f + 0.75f) * ease
        val waistLine = 17.0f
        val backChestWidth = (chest / 4.0f + 0.75f) * ease
        val backWaistWidth = (waist / 4.0f + 0.75f) * ease
        val neckWidth = chest / 12.0f + 0.5f
        val shoulderWidth = (shoulder / 2.0f) + 0.25f // includes back dart allowance
        val shoulderDrop = 1.2f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 40f
        val oy = 40f

        val pBackNeckCenter = DraftPoint("BN0", "0", ox, oy, "Center Back Neck")
        val pBackNeckTop = DraftPoint("BN1", "1", ox + neckWidth * SCALE, oy - 0.75f * SCALE, "Back Neck Elevation")
        val pBackShoulder = DraftPoint("BS1", "2", ox + shoulderWidth * SCALE, oy + shoulderDrop * SCALE, "Back Shoulder Point")
        val pBackScye = DraftPoint("BB1", "3", ox, oy + scyeDepth * SCALE, "Scye Level Center")
        val pBackChest = DraftPoint("BB2", "4", ox + backChestWidth * SCALE, oy + scyeDepth * SCALE, "Back Scye Width")
        val pBackWaist = DraftPoint("BW1", "5", ox + 0.5f * SCALE, oy + waistLine * SCALE, "Center Back Waist Inset")
        val pBackWaistSide = DraftPoint("BW2", "6", ox + backWaistWidth * SCALE, oy + waistLine * SCALE, "Back Waist Width")
        val pBackHem = DraftPoint("BH1", "7", ox + 0.5f * SCALE, oy + length * SCALE, "Center Back Hem")
        val pBackHemSide = DraftPoint("BH2", "8", ox + (backWaistWidth + 0.5f) * SCALE, oy + length * SCALE, "Back Hem Width")

        pts.addAll(listOf(pBackNeckCenter, pBackNeckTop, pBackShoulder, pBackScye, pBackChest, pBackWaist, pBackWaistSide, pBackHem, pBackHemSide))

        lns.add(DraftLine("BN1", "BS1", LineType.OUTLINE, "Back Shoulder Seam"))
        lns.add(DraftLine("BN0", "BW1", LineType.OUTLINE, "Center Back Upper Seam"))
        lns.add(DraftLine("BW1", "BH1", LineType.OUTLINE, "Center Back Seam / Vent"))
        lns.add(DraftLine("BH1", "BH2", LineType.OUTLINE, "Back Bottom Hem"))
        lns.add(DraftLine("BW2", "BH2", LineType.OUTLINE, "Lower Side Seam"))

        // Back neck curve (BN0 to BN1)
        crvs.add(DraftCurve("BN0", ox + (neckWidth * 0.4f) * SCALE, oy - 0.1f * SCALE, ox + (neckWidth * 0.8f) * SCALE, oy - 0.5f * SCALE, "BN1"))

        // Back Armhole Scye (BS1 to BB2)
        crvs.add(DraftCurve(
            startPointId = "BS1",
            control1X = ox + (shoulderWidth - 0.2f) * SCALE,
            control1Y = oy + (scyeDepth * 0.4f) * SCALE,
            control2X = ox + (backChestWidth - 0.8f) * SCALE,
            control2Y = oy + (scyeDepth - 0.3f) * SCALE,
            endPointId = "BB2",
            label = "Back Armhole Curve"
        ))

        // Back Side Seam shaping (BB2 to BW2)
        crvs.add(DraftCurve("BB2", ox + (backChestWidth - 0.2f) * SCALE, oy + (scyeDepth + (waistLine - scyeDepth) * 0.5f) * SCALE, ox + (backWaistWidth + 0.2f) * SCALE, oy + (waistLine - 0.5f) * SCALE, "BW2"))

        lbls.add(DraftLabel("COAT BACK PANEL", ox + 1.5f * SCALE, oy + 5.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pieces (Back Center Seam)", ox + 1.5f * SCALE, oy + 6.2f * SCALE))

        val formulas = listOf(
            FormulaStep("Back Neck Elevation", "0.75\" above origin", "0.75\"", "Provides collar stand fit"),
            FormulaStep("Back Chest Width", "(Chest / 4 + 0.75\") * Fit", "%.2f\"".format(backChestWidth), "Back width with scye margin"),
            FormulaStep("Center Back Inset", "0.5\" shaping at waist", "0.50\"", "Follows spinal curvature")
        )

        return PatternPieceData(
            pieceName = "Coat Back Panel",
            category = PatternType.COAT,
            points = pts,
            lines = lns,
            curves = crvs,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + 1.5f * SCALE, oy + 8.0f * SCALE),
            grainLineEnd = Pair(ox + 1.5f * SCALE, oy + (length - 3.0f) * SCALE),
            widthInches = backChestWidth + 2f,
            heightInches = length + 2f
        )
    }

    private fun calculateCoatSleeve(m: ClientMeasurement, ease: Float): PatternPieceData {
        val sleeveLen = m.coatSleeveLength
        val chest = m.coatChest
        val crownHeight = (chest / 4.0f - 1.0f) * ease
        val bicepsWidth = (chest / 3.0f + 1.0f) * ease
        val wristWidth = 6.25f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 50f
        val oy = 40f

        val pCrownTop = DraftPoint("SL0", "Crown", ox + (bicepsWidth / 2.0f) * SCALE, oy, "Sleeve Crown Top")
        val pBicepsLeft = DraftPoint("SL1", "Biceps L", ox, oy + crownHeight * SCALE, "Left Biceps")
        val pBicepsRight = DraftPoint("SL2", "Biceps R", ox + bicepsWidth * SCALE, oy + crownHeight * SCALE, "Right Biceps")
        val pElbowLeft = DraftPoint("SL3", "Elbow L", ox + 0.5f * SCALE, oy + (crownHeight + 12f) * SCALE, "Elbow Level")
        val pElbowRight = DraftPoint("SL4", "Elbow R", ox + (bicepsWidth - 0.5f) * SCALE, oy + (crownHeight + 12f) * SCALE, "Elbow Right")
        val pWristLeft = DraftPoint("SL5", "Wrist L", ox + 1.0f * SCALE, oy + sleeveLen * SCALE, "Wrist Left")
        val pWristRight = DraftPoint("SL6", "Wrist R", ox + (1.0f + wristWidth) * SCALE, oy + sleeveLen * SCALE, "Wrist Right")

        pts.addAll(listOf(pCrownTop, pBicepsLeft, pBicepsRight, pElbowLeft, pElbowRight, pWristLeft, pWristRight))

        lns.add(DraftLine("SL1", "SL3", LineType.OUTLINE))
        lns.add(DraftLine("SL3", "SL5", LineType.OUTLINE))
        lns.add(DraftLine("SL2", "SL4", LineType.OUTLINE))
        lns.add(DraftLine("SL4", "SL6", LineType.OUTLINE))
        lns.add(DraftLine("SL5", "SL6", LineType.OUTLINE, "Wrist Opening"))

        // Sleeve Crown Curves (SL1 -> SL0 -> SL2)
        crvs.add(DraftCurve("SL1", ox + 0.5f * SCALE, oy + (crownHeight * 0.3f) * SCALE, ox + (bicepsWidth * 0.2f) * SCALE, oy, "SL0", label = "Front Crown"))
        crvs.add(DraftCurve("SL0", ox + (bicepsWidth * 0.8f) * SCALE, oy, ox + (bicepsWidth - 0.5f) * SCALE, oy + (crownHeight * 0.3f) * SCALE, "SL2", label = "Back Crown"))

        lbls.add(DraftLabel("COAT SLEEVE (TOP SLEEVE)", ox + 1.0f * SCALE, oy + crownHeight * SCALE + 4f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pairs (Top & Under Sleeve)", ox + 1.0f * SCALE, oy + crownHeight * SCALE + 5.2f * SCALE))

        val formulas = listOf(
            FormulaStep("Sleeve Crown Height", "Chest / 4 - 1.0\"", "%.2f\"".format(crownHeight), "Height of sleeve cap curve"),
            FormulaStep("Biceps Circumference", "Chest / 3 + 1.0\"", "%.2f\"".format(bicepsWidth), "Armhole cap circumference matching"),
            FormulaStep("Wrist Opening", "Standard tailored cuff", "%.2f\"".format(wristWidth), "Sleeve bottom width")
        )

        return PatternPieceData(
            pieceName = "Coat Sleeve Pattern",
            category = PatternType.COAT,
            points = pts,
            lines = lns,
            curves = crvs,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + (bicepsWidth / 2.0f) * SCALE, oy + 2.0f * SCALE),
            grainLineEnd = Pair(ox + (bicepsWidth / 2.0f) * SCALE, oy + (sleeveLen - 2.0f) * SCALE),
            widthInches = bicepsWidth + 2f,
            heightInches = sleeveLen + 2f
        )
    }

    // ==========================================
    // TROUSER DRAFTING FORMULAS
    // ==========================================

    private fun calculateTrouserFront(m: ClientMeasurement, ease: Float): PatternPieceData {
        val waist = m.trouserWaist
        val hip = m.trouserHip
        val length = m.trouserLength
        val inseam = m.trouserInseam
        val rise = (length - inseam).coerceAtLeast(9.5f)

        val crotchDepth = (hip / 4.0f + 0.75f) * ease
        val frontWaist = waist / 4.0f + 0.5f
        val frontHip = (hip / 4.0f + 0.5f) * ease
        val crotchExtension = hip / 16.0f + 0.25f
        val kneeLine = rise + inseam / 2.0f + 2.0f
        val bottomWidth = 8.5f
        val creaseX = frontHip * 0.5f + crotchExtension * 0.5f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val drts = mutableListOf<DraftDart>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 60f
        val oy = 40f

        val pWaistCenter = DraftPoint("TW0", "Center Waist", ox + crotchExtension * SCALE, oy, "Front Crotch Line Waist")
        val pWaistSide = DraftPoint("TW1", "Waist Side", ox + (crotchExtension + frontWaist) * SCALE, oy, "Front Waist Side")
        val pHipSide = DraftPoint("TH1", "Hip Side", ox + (crotchExtension + frontHip) * SCALE, oy + (crotchDepth * 0.6f) * SCALE, "Front Hip Curve Point")
        val pCrotchInseam = DraftPoint("TC1", "Crotch Point", ox, oy + crotchDepth * SCALE, "Front Crotch Extension")
        val pCrotchLevelSide = DraftPoint("TC2", "Crotch Side", ox + (crotchExtension + frontHip) * SCALE, oy + crotchDepth * SCALE, "Crotch Level Side Seam")
        
        val pKneeInseam = DraftPoint("TK1", "Knee Inseam", ox + (creaseX - 4.5f) * SCALE, oy + kneeLine * SCALE, "Knee Inseam")
        val pKneeOutseam = DraftPoint("TK2", "Knee Outseam", ox + (creaseX + 4.5f) * SCALE, oy + kneeLine * SCALE, "Knee Outseam")
        
        val pHemInseam = DraftPoint("THM1", "Hem Inseam", ox + (creaseX - bottomWidth / 2.0f) * SCALE, oy + length * SCALE, "Bottom Hem Inseam")
        val pHemOutseam = DraftPoint("THM2", "Hem Outseam", ox + (creaseX + bottomWidth / 2.0f) * SCALE, oy + length * SCALE, "Bottom Hem Outseam")

        pts.addAll(listOf(pWaistCenter, pWaistSide, pHipSide, pCrotchInseam, pCrotchLevelSide, pKneeInseam, pKneeOutseam, pHemInseam, pHemOutseam))

        lns.add(DraftLine("TW0", "TW1", LineType.OUTLINE, "Waistband Seam"))
        lns.add(DraftLine("TW0", "TC1", LineType.CONSTRUCTION, "Front Rise Line"))
        lns.add(DraftLine("TK1", "THM1", LineType.OUTLINE, "Lower Inseam"))
        lns.add(DraftLine("TK2", "THM2", LineType.OUTLINE, "Lower Outseam"))
        lns.add(DraftLine("THM1", "THM2", LineType.OUTLINE, "Bottom Hem Line"))

        // Crease / Grainline Vertical
        lns.add(DraftLine("TC1", "THM1", LineType.CONSTRUCTION))
        
        // Front Crotch Curve (TW0 -> TC1)
        crvs.add(DraftCurve(
            startPointId = "TW0",
            control1X = ox + crotchExtension * SCALE,
            control1Y = oy + (crotchDepth * 0.5f) * SCALE,
            control2X = ox + (crotchExtension * 0.3f) * SCALE,
            control2Y = oy + (crotchDepth - 0.2f) * SCALE,
            endPointId = "TC1",
            label = "Front Crotch Curve"
        ))

        // Inseam Curve (TC1 -> TK1)
        crvs.add(DraftCurve("TC1", ox + (crotchExtension * 0.5f) * SCALE, oy + (crotchDepth + (kneeLine - crotchDepth) * 0.4f) * SCALE, ox + (creaseX - 4.6f) * SCALE, oy + (kneeLine - 1f) * SCALE, "TK1"))

        // Outseam Curve (TW1 -> pHipSide -> pKneeOutseam)
        crvs.add(DraftCurve("TW1", ox + (crotchExtension + frontWaist + 0.4f) * SCALE, oy + (crotchDepth * 0.3f) * SCALE, ox + (crotchExtension + frontHip) * SCALE, oy + (crotchDepth * 0.6f) * SCALE, "TH1"))
        crvs.add(DraftCurve("TH1", ox + (crotchExtension + frontHip) * SCALE, oy + crotchDepth * SCALE, ox + (creaseX + 4.6f) * SCALE, oy + (kneeLine - 1f) * SCALE, "TK2"))

        // Front Pleat / Dart
        val dartX = ox + (creaseX * SCALE)
        drts.add(DraftDart(dartX, oy + 3.0f * SCALE, dartX - 0.25f * SCALE, oy, dartX + 0.25f * SCALE, oy))

        lbls.add(DraftLabel("TROUSER FRONT PANEL", ox + (creaseX - 1f) * SCALE, oy + crotchDepth * SCALE + 3.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pieces (Left & Right)", ox + (creaseX - 1f) * SCALE, oy + crotchDepth * SCALE + 4.2f * SCALE))

        val formulas = listOf(
            FormulaStep("Crotch Depth", "Hip / 4 + 0.75\"", "%.2f\"".format(crotchDepth), "Distance from waist to crotch level"),
            FormulaStep("Front Crotch Extension", "Hip / 16 + 0.25\"", "%.2f\"".format(crotchExtension), "Front seat curve extension"),
            FormulaStep("Front Waist", "Waist / 4 + 0.5\" (Dart)", "%.2f\"".format(frontWaist), "Waistband front measurement"),
            FormulaStep("Crease Line Axis", "(Front Hip + Extension) / 2", "Centered", "Vertical pressing crease and grain line")
        )

        return PatternPieceData(
            pieceName = "Trouser Front Panel",
            category = PatternType.TROUSER,
            points = pts,
            lines = lns,
            curves = crvs,
            darts = drts,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + creaseX * SCALE, oy + 1.0f * SCALE),
            grainLineEnd = Pair(ox + creaseX * SCALE, oy + (length - 1.0f) * SCALE),
            widthInches = frontHip + crotchExtension + 2f,
            heightInches = length + 2f
        )
    }

    private fun calculateTrouserBack(m: ClientMeasurement, ease: Float): PatternPieceData {
        val waist = m.trouserWaist
        val hip = m.trouserHip
        val length = m.trouserLength
        val inseam = m.trouserInseam
        val rise = (length - inseam).coerceAtLeast(9.5f)

        val crotchDepth = (hip / 4.0f + 0.75f) * ease
        val backWaist = waist / 4.0f + 1.25f // includes 0.75" back dart
        val backHip = (hip / 4.0f + 1.25f) * ease
        val backCrotchExt = hip / 8.0f + 0.5f
        val kneeLine = rise + inseam / 2.0f + 2.0f
        val bottomWidth = 9.0f
        val creaseX = backHip * 0.5f + backCrotchExt * 0.5f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val drts = mutableListOf<DraftDart>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 60f
        val oy = 40f

        // Back waist is elevated 1.5" higher at center back for seat curve
        val pBackWaistCenter = DraftPoint("BTW0", "Back Center Waist", ox + (backCrotchExt - 1.5f) * SCALE, oy - 1.5f * SCALE, "Elevated Back Rise Point")
        val pBackWaistSide = DraftPoint("BTW1", "Back Side Waist", ox + (backCrotchExt - 1.5f + backWaist) * SCALE, oy, "Back Waist Outseam")
        val pBackCrotchInseam = DraftPoint("BTC1", "Back Crotch Ext", ox, oy + (crotchDepth + 0.5f) * SCALE, "Back Crotch Extension Point")
        
        val pKneeInseam = DraftPoint("BTK1", "Knee Inseam", ox + (creaseX - 5.0f) * SCALE, oy + kneeLine * SCALE, "Back Knee Inseam")
        val pKneeOutseam = DraftPoint("BTK2", "Knee Outseam", ox + (creaseX + 5.0f) * SCALE, oy + kneeLine * SCALE, "Back Knee Outseam")
        
        val pHemInseam = DraftPoint("BTHM1", "Hem Inseam", ox + (creaseX - bottomWidth / 2.0f) * SCALE, oy + length * SCALE, "Back Hem Inseam")
        val pHemOutseam = DraftPoint("BTHM2", "Hem Outseam", ox + (creaseX + bottomWidth / 2.0f) * SCALE, oy + length * SCALE, "Back Hem Outseam")

        pts.addAll(listOf(pBackWaistCenter, pBackWaistSide, pBackCrotchInseam, pKneeInseam, pKneeOutseam, pHemInseam, pHemOutseam))

        lns.add(DraftLine("BTW0", "BTW1", LineType.OUTLINE, "Back Waistband"))
        lns.add(DraftLine("BTK1", "BTHM1", LineType.OUTLINE))
        lns.add(DraftLine("BTK2", "BTHM2", LineType.OUTLINE))
        lns.add(DraftLine("BTHM1", "BTHM2", LineType.OUTLINE, "Back Bottom Hem"))

        // Back Crotch Curve (BTW0 -> BTC1)
        crvs.add(DraftCurve(
            startPointId = "BTW0",
            control1X = ox + (backCrotchExt * 0.7f) * SCALE,
            control1Y = oy + (crotchDepth * 0.4f) * SCALE,
            control2X = ox + (backCrotchExt * 0.2f) * SCALE,
            control2Y = oy + (crotchDepth + 0.2f) * SCALE,
            endPointId = "BTC1",
            label = "Deep Back Crotch Curve"
        ))

        // Back Inseam Curve (BTC1 -> BTK1)
        crvs.add(DraftCurve("BTC1", ox + (backCrotchExt * 0.4f) * SCALE, oy + (crotchDepth + (kneeLine - crotchDepth) * 0.4f) * SCALE, ox + (creaseX - 5.1f) * SCALE, oy + (kneeLine - 1f) * SCALE, "BTK1"))

        // Back Outseam Curve (BTW1 -> BTK2)
        crvs.add(DraftCurve("BTW1", ox + (backCrotchExt + backHip) * SCALE, oy + (crotchDepth * 0.5f) * SCALE, ox + (creaseX + 5.1f) * SCALE, oy + (kneeLine - 1f) * SCALE, "BTK2"))

        // Back Waist Dart
        val dartX = ox + (backCrotchExt - 1.5f + backWaist * 0.5f) * SCALE
        val dartY = oy - 0.75f * SCALE
        drts.add(DraftDart(dartX, dartY + 3.5f * SCALE, dartX - 0.375f * SCALE, dartY, dartX + 0.375f * SCALE, dartY))

        lbls.add(DraftLabel("TROUSER BACK PANEL", ox + (creaseX - 1f) * SCALE, oy + crotchDepth * SCALE + 3.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pieces (Left & Right)", ox + (creaseX - 1f) * SCALE, oy + crotchDepth * SCALE + 4.2f * SCALE))

        val formulas = listOf(
            FormulaStep("Back Rise Elevation", "+1.5\" above waist line", "1.50\"", "Provides seat height depth when seated"),
            FormulaStep("Back Crotch Extension", "Hip / 8 + 0.5\"", "%.2f\"".format(backCrotchExt), "Extended room for posterior movement"),
            FormulaStep("Back Waist Dart", "0.75\" width x 3.5\" length", "0.75\"", "Shapes waistband to lumbar curve")
        )

        return PatternPieceData(
            pieceName = "Trouser Back Panel",
            category = PatternType.TROUSER,
            points = pts,
            lines = lns,
            curves = crvs,
            darts = drts,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + creaseX * SCALE, oy + 1.0f * SCALE),
            grainLineEnd = Pair(ox + creaseX * SCALE, oy + (length - 1.0f) * SCALE),
            widthInches = backHip + backCrotchExt + 2f,
            heightInches = length + 2f
        )
    }

    // ==========================================
    // WAISTCOAT DRAFTING FORMULAS
    // ==========================================

    private fun calculateWaistcoatFront(m: ClientMeasurement, ease: Float): PatternPieceData {
        val shoulder = m.waistcoatShoulder
        val chest = m.waistcoatChest
        val waist = m.waistcoatWaist
        val length = m.waistcoatLength

        val scyeDepth = (chest / 4.0f + 0.5f) * ease
        val waistLine = 16.5f
        val chestWidth = (chest / 4.0f + 0.75f) * ease
        val waistWidth = (waist / 4.0f + 0.5f) * ease
        val neckWidth = chest / 12.0f + 0.25f
        val vNeckDrop = 12.5f
        val frontPeakExt = 2.5f // Pointed front waist bottom extension
        val shoulderWidth = (shoulder / 2.0f) - 0.5f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val drts = mutableListOf<DraftDart>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 60f
        val oy = 40f

        val pNeckStart = DraftPoint("WN0", "0", ox, oy, "Neck Origin")
        val pNeckTop = DraftPoint("WN1", "1", ox + neckWidth * SCALE, oy, "Neck Shoulder Point")
        val pShoulderTip = DraftPoint("WS1", "2", ox + shoulderWidth * SCALE, oy + 1.2f * SCALE, "Waistcoat Shoulder Point")
        val pChestPoint = DraftPoint("WB1", "3", ox + chestWidth * SCALE, oy + scyeDepth * SCALE, "Chest Side Level")
        val pVNeckApex = DraftPoint("WV1", "V-Neck", ox, oy + vNeckDrop * SCALE, "Front V-Neck Opening Level")
        val pWaistSide = DraftPoint("WW1", "4", ox + waistWidth * SCALE, oy + waistLine * SCALE, "Waist Side Seam")
        val pFrontPeak = DraftPoint("WP1", "Peak", ox, oy + (length) * SCALE, "Waistcoat Front Pointed Peak")
        val pHemSide = DraftPoint("WH1", "5", ox + waistWidth * SCALE, oy + (length - frontPeakExt) * SCALE, "Side Hem Level")

        pts.addAll(listOf(pNeckStart, pNeckTop, pShoulderTip, pChestPoint, pVNeckApex, pWaistSide, pFrontPeak, pHemSide))

        lns.add(DraftLine("WN1", "WS1", LineType.OUTLINE, "Shoulder Seam"))
        lns.add(DraftLine("WN1", "WV1", LineType.OUTLINE, "V-Neck Line"))
        lns.add(DraftLine("WV1", "WP1", LineType.OUTLINE, "Front Button Closure"))
        lns.add(DraftLine("WP1", "WH1", LineType.OUTLINE, "Pointed Front Bottom Curve"))
        lns.add(DraftLine("WW1", "WH1", LineType.OUTLINE, "Lower Side Seam"))

        // Armhole Scye Curve (WS1 -> WB1)
        crvs.add(DraftCurve(
            startPointId = "WS1",
            control1X = ox + (shoulderWidth - 0.5f) * SCALE,
            control1Y = oy + (scyeDepth * 0.5f) * SCALE,
            control2X = ox + (chestWidth - 0.8f) * SCALE,
            control2Y = oy + (scyeDepth - 0.3f) * SCALE,
            endPointId = "WB1",
            label = "Vest Armhole Scye"
        ))

        // Side Seam shaping (WB1 -> WW1)
        crvs.add(DraftCurve("WB1", ox + (chestWidth - 0.2f) * SCALE, oy + (scyeDepth + 2f) * SCALE, ox + (waistWidth + 0.2f) * SCALE, oy + (waistLine - 1f) * SCALE, "WW1"))

        // Front Dart
        val dartX = ox + (chestWidth * 0.5f) * SCALE
        drts.add(DraftDart(dartX, oy + (scyeDepth + 1.0f) * SCALE, dartX - 0.3f * SCALE, oy + waistLine * SCALE, dartX + 0.3f * SCALE, oy + waistLine * SCALE))

        // Pocket Welt markings
        lns.add(DraftLine("P1", "P2", LineType.CONSTRUCTION, "Lower Pocket Welt (4.5\")"))

        lbls.add(DraftLabel("WAISTCOAT FRONT PANEL", ox + 1.5f * SCALE, oy + 5.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 2 Pieces (Main Outer Fabric)", ox + 1.5f * SCALE, oy + 6.2f * SCALE))

        val formulas = listOf(
            FormulaStep("V-Neck Drop", "12.5\" from neck origin", "12.50\"", "Front V-opening length for tie visibility"),
            FormulaStep("Front Pointed Peak", "+2.5\" extension below waist", "2.50\"", "Classic waistcoat front bottom points"),
            FormulaStep("Chest Width", "(Chest / 4 + 0.75\") * Fit", "%.2f\"".format(chestWidth), "Snug tailored vest fit")
        )

        return PatternPieceData(
            pieceName = "Waistcoat Front Panel",
            category = PatternType.WAISTCOAT,
            points = pts,
            lines = lns,
            curves = crvs,
            darts = drts,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + 1.5f * SCALE, oy + 7.0f * SCALE),
            grainLineEnd = Pair(ox + 1.5f * SCALE, oy + (length - 4.0f) * SCALE),
            widthInches = chestWidth + 2f,
            heightInches = length + 2f
        )
    }

    private fun calculateWaistcoatBack(m: ClientMeasurement, ease: Float): PatternPieceData {
        val shoulder = m.waistcoatShoulder
        val chest = m.waistcoatChest
        val waist = m.waistcoatWaist
        val length = m.waistcoatLength - 2.5f // Back is straight without front points

        val scyeDepth = (chest / 4.0f + 0.5f) * ease
        val waistLine = 16.5f
        val backChestWidth = (chest / 4.0f + 0.5f) * ease
        val backWaistWidth = (waist / 4.0f + 0.25f) * ease
        val neckWidth = chest / 12.0f + 0.25f
        val shoulderWidth = (shoulder / 2.0f) - 0.25f

        val pts = mutableListOf<DraftPoint>()
        val lns = mutableListOf<DraftLine>()
        val crvs = mutableListOf<DraftCurve>()
        val drts = mutableListOf<DraftDart>()
        val lbls = mutableListOf<DraftLabel>()

        val ox = 50f
        val oy = 40f

        val pBackNeckCenter = DraftPoint("BWN0", "0", ox, oy, "Back Neck Center")
        val pBackNeckTop = DraftPoint("BWN1", "1", ox + neckWidth * SCALE, oy - 0.5f * SCALE, "Back Neck Curve Top")
        val pBackShoulder = DraftPoint("BWS1", "2", ox + shoulderWidth * SCALE, oy + 1.0f * SCALE, "Back Shoulder Point")
        val pBackChest = DraftPoint("BWB1", "3", ox + backChestWidth * SCALE, oy + scyeDepth * SCALE, "Back Chest Width")
        val pBackWaistCenter = DraftPoint("BWW0", "4", ox, oy + waistLine * SCALE, "Center Back Waist")
        val pBackWaistSide = DraftPoint("BWW1", "5", ox + backWaistWidth * SCALE, oy + waistLine * SCALE, "Back Waist Side")
        val pBackHemCenter = DraftPoint("BWH0", "6", ox, oy + length * SCALE, "Center Back Hem")
        val pBackHemSide = DraftPoint("BWH1", "7", ox + backWaistWidth * SCALE, oy + length * SCALE, "Back Side Hem")

        pts.addAll(listOf(pBackNeckCenter, pBackNeckTop, pBackShoulder, pBackChest, pBackWaistCenter, pBackWaistSide, pBackHemCenter, pBackHemSide))

        lns.add(DraftLine("BWN1", "BWS1", LineType.OUTLINE, "Shoulder Seam"))
        lns.add(DraftLine("BWN0", "BWH0", LineType.CENTER_LINE, "Center Back Fold Line"))
        lns.add(DraftLine("BWH0", "BWH1", LineType.OUTLINE, "Straight Back Hem"))
        lns.add(DraftLine("BWW1", "BWH1", LineType.OUTLINE, "Lower Side Seam"))

        // Back Neck Curve
        crvs.add(DraftCurve("BWN0", ox + (neckWidth * 0.5f) * SCALE, oy, ox + (neckWidth * 0.8f) * SCALE, oy - 0.4f * SCALE, "BWN1"))

        // Back Armhole Scye (BWS1 -> BWB1)
        crvs.add(DraftCurve("BWS1", ox + (shoulderWidth - 0.4f) * SCALE, oy + (scyeDepth * 0.5f) * SCALE, ox + (backChestWidth - 0.6f) * SCALE, oy + (scyeDepth - 0.2f) * SCALE, "BWB1"))

        // Back Side Seam shaping (BWB1 -> BWW1)
        crvs.add(DraftCurve("BWB1", ox + (backChestWidth - 0.2f) * SCALE, oy + (scyeDepth + 2f) * SCALE, ox + (backWaistWidth + 0.2f) * SCALE, oy + (waistLine - 1f) * SCALE, "BWW1"))

        // Adjustable Back Strap Line
        lns.add(DraftLine("STRAP1", "STRAP2", LineType.CONSTRUCTION, "Adjustable Back Strap / Buckle Line"))

        lbls.add(DraftLabel("WAISTCOAT BACK PANEL", ox + 1.5f * SCALE, oy + 5.0f * SCALE, isHeader = true))
        lbls.add(DraftLabel("Cut 1 Piece on Fold (Lining Fabric)", ox + 1.5f * SCALE, oy + 6.2f * SCALE))

        val formulas = listOf(
            FormulaStep("Back Neck Width", "Chest / 12 + 0.25\"", "%.2f\"".format(neckWidth), "Shallow back neck stand"),
            FormulaStep("Back Length", "Front Length - 2.5\"", "%.2f\"".format(length), "Clean straight back hemline"),
            FormulaStep("Back Waist Strap", "1.5\" below waist level", "Adjustable", "Tightens vest silhouette at back")
        )

        return PatternPieceData(
            pieceName = "Waistcoat Back Panel",
            category = PatternType.WAISTCOAT,
            points = pts,
            lines = lns,
            curves = crvs,
            labels = lbls,
            formulas = formulas,
            grainLineStart = Pair(ox + 1.5f * SCALE, oy + 7.0f * SCALE),
            grainLineEnd = Pair(ox + 1.5f * SCALE, oy + (length - 2.0f) * SCALE),
            widthInches = backChestWidth + 2f,
            heightInches = length + 2f
        )
    }
}
