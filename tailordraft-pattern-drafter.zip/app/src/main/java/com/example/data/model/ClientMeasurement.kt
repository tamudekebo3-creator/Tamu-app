package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "client_measurements")
data class ClientMeasurement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientName: String,
    val unit: String = "INCHES", // "INCHES" or "CM"
    val fitType: String = "REGULAR", // "SLIM", "REGULAR", "RELAXED"
    
    // Coat Measurements
    val coatBackLength: Float = 29.0f,
    val coatShoulder: Float = 18.0f,
    val coatChest: Float = 40.0f,
    val coatWaist: Float = 34.0f,
    val coatSleeveLength: Float = 25.0f,
    
    // Trouser Measurements
    val trouserLength: Float = 40.0f,
    val trouserWaist: Float = 34.0f,
    val trouserHip: Float = 40.0f,
    val trouserInseam: Float = 30.0f,
    
    // Waistcoat Measurements
    val waistcoatShoulder: Float = 15.0f,
    val waistcoatChest: Float = 40.0f,
    val waistcoatWaist: Float = 34.0f,
    val waistcoatLength: Float = 23.0f,
    
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
