package com.example.data.model

enum class PatternType(val displayName: String) {
    COAT("Coat / Jacket"),
    TROUSER("Trouser / Pants"),
    WAISTCOAT("Waistcoat / Vest")
}

enum class MeasurementUnit(val symbol: String) {
    INCHES("in"),
    CENTIMETERS("cm")
}

enum class FitStyle(val displayName: String, val easeMultiplier: Float) {
    SLIM("Slim Fit", 0.85f),
    REGULAR("Classic Regular", 1.0f),
    RELAXED("Comfort / Relaxed", 1.15f)
}

enum class LineType {
    OUTLINE,        // Solid primary cut line
    SEAM_ALLOWANCE, // Dashed seam allowance line
    CENTER_LINE,    // Fold or center grain line
    DART_LINE,      // Dart construction
    CONSTRUCTION    // Light grid / reference draft line
}

data class DraftPoint(
    val id: String,
    val label: String,
    val x: Float,
    val y: Float,
    val description: String = ""
)

data class DraftLine(
    val fromPointId: String,
    val toPointId: String,
    val lineType: LineType = LineType.OUTLINE,
    val label: String = ""
)

data class DraftCurve(
    val startPointId: String,
    val control1X: Float,
    val control1Y: Float,
    val control2X: Float,
    val control2Y: Float,
    val endPointId: String,
    val lineType: LineType = LineType.OUTLINE,
    val label: String = ""
)

data class DraftDart(
    val apexX: Float,
    val apexY: Float,
    val leftX: Float,
    val leftY: Float,
    val rightX: Float,
    val rightY: Float
)

data class DraftLabel(
    val text: String,
    val x: Float,
    val y: Float,
    val isHeader: Boolean = false
)

data class FormulaStep(
    val stepName: String,
    val formulaText: String,
    val calculatedValue: String,
    val explanation: String
)

data class PatternPieceData(
    val pieceName: String,
    val category: PatternType,
    val points: List<DraftPoint>,
    val lines: List<DraftLine>,
    val curves: List<DraftCurve>,
    val darts: List<DraftDart> = emptyList(),
    val labels: List<DraftLabel> = emptyList(),
    val formulas: List<FormulaStep> = emptyList(),
    val grainLineStart: Pair<Float, Float>? = null,
    val grainLineEnd: Pair<Float, Float>? = null,
    val widthInches: Float = 0f,
    val heightInches: Float = 0f
)
