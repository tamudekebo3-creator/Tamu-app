package com.example.data.repository

import com.example.data.local.ClientDao
import com.example.data.model.ClientMeasurement
import kotlinx.coroutines.flow.Flow

class ClientRepository(private val dao: ClientDao) {

    val allClients: Flow<List<ClientMeasurement>> = dao.getAllClients()

    suspend fun saveClient(client: ClientMeasurement): Long {
        return dao.insertClient(client)
    }

    suspend fun deleteClient(id: Long) {
        dao.deleteClientById(id)
    }

    suspend fun getClient(id: Long): ClientMeasurement? {
        return dao.getClientById(id)
    }

    // Default Preset Measurement Templates
    companion object {
        val PRESET_MEDIUM_M38 = ClientMeasurement(
            id = -1,
            clientName = "Default Standard (Chest 40\" / Waist 34\")",
            unit = "INCHES",
            fitType = "REGULAR",
            coatBackLength = 29.0f,
            coatShoulder = 18.0f,
            coatChest = 40.0f,
            coatWaist = 34.0f,
            coatSleeveLength = 25.0f,
            trouserLength = 40.0f,
            trouserWaist = 34.0f,
            trouserHip = 40.0f,
            trouserInseam = 30.0f,
            waistcoatShoulder = 15.0f,
            waistcoatChest = 40.0f,
            waistcoatWaist = 34.0f,
            waistcoatLength = 23.0f,
            notes = "Standard Men's Medium Tailored Suit Profile"
        )

        val PRESET_SLIM_S36 = ClientMeasurement(
            id = -2,
            clientName = "Slim Fit (Chest 36\" / Waist 30\")",
            unit = "INCHES",
            fitType = "SLIM",
            coatBackLength = 28.0f,
            coatShoulder = 17.0f,
            coatChest = 36.0f,
            coatWaist = 30.0f,
            coatSleeveLength = 24.5f,
            trouserLength = 39.0f,
            trouserWaist = 30.0f,
            trouserHip = 36.0f,
            trouserInseam = 29.5f,
            waistcoatShoulder = 14.0f,
            waistcoatChest = 36.0f,
            waistcoatWaist = 30.0f,
            waistcoatLength = 22.0f,
            notes = "Modern European Slim Fit"
        )

        val PRESET_LARGE_L44 = ClientMeasurement(
            id = -3,
            clientName = "Executive Large (Chest 44\" / Waist 38\")",
            unit = "INCHES",
            fitType = "REGULAR",
            coatBackLength = 30.5f,
            coatShoulder = 19.5f,
            coatChest = 44.0f,
            coatWaist = 38.0f,
            coatSleeveLength = 26.0f,
            trouserLength = 41.5f,
            trouserWaist = 38.0f,
            trouserHip = 44.0f,
            trouserInseam = 31.0f,
            waistcoatShoulder = 16.5f,
            waistcoatChest = 44.0f,
            waistcoatWaist = 38.0f,
            waistcoatLength = 24.0f,
            notes = "Executive Savile Row Classic"
        )
    }
}
