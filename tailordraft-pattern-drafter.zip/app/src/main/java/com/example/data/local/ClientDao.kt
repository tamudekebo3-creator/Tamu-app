package com.example.data.local

import androidx.room.*
import com.example.data.model.ClientMeasurement
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("SELECT * FROM client_measurements ORDER BY updatedAt DESC")
    fun getAllClients(): Flow<List<ClientMeasurement>>

    @Query("SELECT * FROM client_measurements WHERE id = :id")
    suspend fun getClientById(id: Long): ClientMeasurement?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: ClientMeasurement): Long

    @Update
    suspend fun updateClient(client: ClientMeasurement)

    @Delete
    suspend fun deleteClient(client: ClientMeasurement)

    @Query("DELETE FROM client_measurements WHERE id = :id")
    suspend fun deleteClientById(id: Long)
}
